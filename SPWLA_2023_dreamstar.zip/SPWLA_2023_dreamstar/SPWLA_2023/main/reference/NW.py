from dtaidistance import alignment
import pandas as pd
import numpy as np


def NW(s1, s2, dig):
    s1 = round(s1, dig)
    s2 = round(s2, dig)
    # s1.reset_index(drop=True, inplace=True)
    # s2.reset_index(drop=True, inplace=True)
    value, scores, paths = alignment.needleman_wunsch(s1, s2)
    algn, s1_nw, s2_nw = alignment.best_alignment(paths, s1, s2, gap='-')
    s1_nw = pd.DataFrame(s1_nw)
    s2_nw = pd.DataFrame(s2_nw)

    s1_s2 = pd.concat([s1_nw, s2_nw], axis=1)
    s1_s2.drop(s1_s2[s1_s2.iloc[:, 0] == '-'].index, inplace=True)
    s1_s2.reset_index(drop=True, inplace=True)
    none_index_12 = s1_s2[s1_s2.iloc[:, 1] == '-'].index
    s1[none_index_12] = None

    s2_s1 = pd.concat([s2_nw, s1_nw], axis=1)
    s2_s1.drop(s2_s1[s2_s1.iloc[:, 0] == '-'].index, inplace=True)
    s2_s1.reset_index(drop=True, inplace=True)
    none_index_21 = s2_s1[s2_s1.iloc[:, 1] == '-'].index
    s2[none_index_21] = None

    s1 = s1.interpolate(method='linear', axis=0)
    s2 = s2.interpolate(method='linear', axis=0)

    s1.fillna(axis=0, method='bfill', inplace=True)
    s2.fillna(axis=0, method='bfill', inplace=True)
    s1.fillna(axis=0, method='ffill', inplace=True)
    s2.fillna(axis=0, method='ffill', inplace=True)

    return s1, s2


if __name__ == '__main__':
    path01 = r"..\data\stretch\test.csv"
    data1 = pd.read_csv(path01)
    s1 = data1['RHOB'][:100]
    s2 = data1['RHOB_pred'][:100]
    s1,s2,a=NW(s1, s2)
    print(s1,'\n',s2)