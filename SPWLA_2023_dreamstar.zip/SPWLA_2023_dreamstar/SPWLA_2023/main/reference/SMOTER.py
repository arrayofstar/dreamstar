# -*- coding: utf-8 -*-
# @Time    : 2023/4/22 12:43
# @Author  : YYY
# @File    : SMOTER.py
# @Desc    : 数据增强算法
# @Link    : [1] https://blog.csdn.net/QKK612501/article/details/129361385 iblr库介绍原文论文
#            [2] https://imbalancedlearningregression.readthedocs.io/en/latest/index.html iblr库原文件
#            [3] https://zhuanlan.zhihu.com/p/354538751 数据预处理-非平衡数据处理

# 加载库
import ImbalancedLearningRegression as iblr
import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置字体
plt.rcParams['axes.unicode_minus'] = False  # 该语句解决图像中的“-”负号的乱码问题


def graph(data, name, y_col, x_col=0, x_l=410, x_r=445, row_l=0, row_r=-1):
    '''
    用于画图
    参数：
        data(DataFrame): 输入数据
        name(str): 图表的标题
        x_col & y_col(int): x轴和y轴对应列, x轴默认DEPTH列
        x_l & x_r(int): x轴的范围, 默认410 to 445
        row_l & row_r(int): 数据元组(行)数范围, 默认所有行
    示例：
        graph(data=data,name="原始数据",y_col=2)

    plot line chart
    Args:
        data(DataFrame): input data
        name(str): the title of the plot
        x_col & y_col(int): the column of the x-axis or y-axis, the value of the x-axis defaults to the DEPTH column
        x_l & x_r(int): the range of the x-axis, default 410 to 445
        row_l & row_r(int): the range of rows, default All Rows
    Example：
        graph(data=data,name="Raw Data",y_col=2)

    '''
    plt.figure(figsize=(10, 5))
    plt.title(name)
    plt.plot(data.iloc[row_l:row_r, x_col], data.iloc[row_l:row_r, y_col])
    plt.xlim(x_l, x_r)
    plt.tight_layout()
    plt.show()


def graph_sum(data, name, y_col, alg_num, c, x_col=0, x_l=410, x_r=445, row_l=0, row_r=-1):
    '''
    用于画汇总图
    参数：
        data(DataFrame): 输入数据
        name(list): 图表的标题
        alg_num(int): 折线条数
        c(list): 折线颜色
        x_col & y_col(int): x轴和y轴对应列, x轴默认DEPTH列
        x_l & x_r(int): x轴的范围, 默认410 to 445
        row_l & row_r(int): 数据元组(行)数范围, 默认所有行
    示例：
        graph_sum(data=data, name=["原始数据", "RO", "RU"], alg_num=2, y_col=2, c=["red", "blue", "black"])
    '''
    plt.figure(figsize=(10, 5))
    for i in range(alg_num):
        plt.title('汇总图')
        plt.plot(data[i].iloc[row_l:row_r, x_col],
                 data[i].iloc[row_l:row_r, y_col],
                 c=c[i],
                 label=name[i],
                 linewidth=1.0)
        plt.xlim(x_l, x_r)
    plt.legend(framealpha=1, frameon=True)
    plt.tight_layout()
    plt.show()


# 算法调用
#        ALG(data,alg_name="RU") 对原始数据"RHOB"特征列进行随即下采样算法调用
# data为输入原始数据,DataFrame类型
# alg_name为算法名称,string类型,有：RO、GN、RU、CNN、ENN、TL、ADA算法
# col为需要随机过采样的特征列名,string类型,默认"RHOB"列
# x为需要排序的特征列名，string类型,默认"DEPTH"列
def ALG(data, alg_name, col='RHOB', x='DEPT', mode=''):
    '''
    用于算法调用
    参数：
        data(DataFrame): 输入数据
        alg_name(string): 算法名称
        col(string): 采样特征列名, 即y轴数据，默认RHOB列
        x(string): x轴数据，默认DEPTH列
        mode(string): 采样类型,分为over-sampling和under-sampling
    示例：
        ALG(data=data, alg_name='RO', col='RHOB', x='DEPT', mode='over-sampling')
    '''
    if mode == 'over-sampling':
        if alg_name == 'RO':  # Random Over-sampling算法
            data_result = iblr.ro(data, col)
        elif alg_name == 'GN':  # SMOGN算法(Introduction of Gaussian Noise算法)导入高斯噪声算法
            data_result = iblr.gn(data, col)
        elif alg_name == 'ADA':  # ADASYN算法
            data_result = iblr.adasyn(data, col)
        else:
            print('ERROR:没有该算法名\n'
                  '请输入正确的算法名称：RO、GN、ADA')
            return -1
    elif mode == 'under-sampling':
        if alg_name == 'RU':  # Random Under-sampling算法
            data_result = iblr.random_under(data, col)
        elif alg_name == 'CNN':  # Condensed Nearest Neighbor算法
            data_result = iblr.cnn(data, col)
        elif alg_name == 'ENN':  # TomekLinks算法
            data_result = iblr.enn(data, col)
        elif alg_name == 'TL':  # Edited Nearest Neighbor算法
            data_result = iblr.tomeklinks(data, col)
        else:
            print('ERROR:没有该算法名\n'
                  '请输入正确的算法名称：RU、CNN、ENN、TL')
            return -1
    else:
        print('ERROR:没有该模式\n'
              '请输入正确的采样模式：over-sampling、under-sampling')
        return -1

    data_result.sort_values(x, inplace=True)  # 按DEPTH升序排序
    return data_result


# main入口 ImbalancedLearningRegression中的几种过采样方法
if __name__ == '__main__':
    # 导入数据，DataFrame类型
    site = r'../data/train/aligned_well_01.csv'
    data = pd.read_csv(site)
    # 调用over-sampling算法
    data_ro = ALG(data, 'RO', col='RHOB', x='DEPT', mode='over-sampling')
    data_ada = ALG(data, 'ADA', col='RHOB', x='DEPT', mode='over-sampling')
    data_gn = ALG(data, 'GN', col='RHOB', x='DEPT', mode='over-sampling')
    # 调用under-sampling算法
    data_ru = ALG(data, 'RU', col='RHOB', x='DEPT', mode='under-sampling')
    data_cnn = ALG(data, 'CNN', col='RHOB', x='DEPT', mode='under-sampling')
    data_enn = ALG(data, 'ENN', col='RHOB', x='DEPT', mode='under-sampling')
    data_tl = ALG(data, 'TL', col='RHOB', x='DEPT', mode='under-sampling')

    # 输出数据shape
    ## print('井1数据原本shape：', data.shape)  # 原本数据shape (8881, 5)
    ## print('随机过采样后的shape：', data_ro.shape)  # 随机过采样后的shape (13067, 5)
    ## print('高斯后的shape：', data_gn.shape)  # 导入高斯噪声后的shape (13067, 5)
    # 导出数据
    ## data_ros.to_csv(r'C:\Users\86183\Desktop\dw1_ro.csv')

    '''
    ---------------------------------------
    绘图--DEPTH特征值
    ---------------------------------------
    '''
    # 绘图-单图
    # 数据准备
    name_list = ['原始数据', 'RO', 'ADA', 'GN', 'RU', 'CNN', 'ENN', 'TL']
    data_list = [data, data_ro, data_ada, data_gn, data_ru, data_cnn, data_enn, data_tl]
    #
    for i in range(len(name_list)):
        graph(data_list[i], name_list[i], y_col=2)

    # 绘图-对比图
    # over-sampling算法数据准备
    over_data_sum = [data, data_ro, data_ada, data_gn]
    over_name_sum = ['原始数据', 'RO', 'ADA', 'GN']
    over_color = ['black', 'red', 'blue', 'green']
    # under-sampling算法数据准备
    under_data_sum = [data, data_ru, data_cnn, data_enn, data_tl]
    under_name_sum = ['原始数据', 'RU', 'CNN', 'ENN', 'TL']
    under_color = ['black', 'red', 'blue', 'green', 'yellow']
    # 不同over-sampling算法对比图
    graph_sum(over_data_sum, over_name_sum, alg_num=4, y_col=2, c=over_color, x_r=1000)
    # 不同under-sampling算法对比图
    graph_sum(under_data_sum, under_name_sum, alg_num=5, y_col=2, c=under_color, x_r=1000)

    # 绘图-子图
    # over-sampling算法
    plt.figure(figsize=(10, 5))
    plt.subplot(4, 1, 1)
    plt.title('原始数据')
    plt.plot(data.iloc[:100, 0], data.iloc[:100, 2])
    plt.xlim(410, 445)
    plt.subplot(4, 1, 2)
    plt.title('RO')
    plt.plot(data_ro.iloc[:100, 0], data_ro.iloc[:100, 2])
    plt.xlim(410, 445)
    plt.subplot(4, 1, 3)
    plt.title('ADA')
    plt.plot(data_ada.iloc[:100, 0], data_ada.iloc[:100, 2])
    plt.xlim(410, 445)
    plt.subplot(4, 1, 4)
    plt.title('GN')
    plt.plot(data_gn.iloc[:100, 0], data_gn.iloc[:100, 3])
    plt.xlim(410, 445)
    plt.tight_layout()
    plt.show()

    # under-sampling算法
    plt.figure(figsize=(10, 5))
    plt.subplot(3, 2, 1)
    plt.title('原始数据')
    plt.plot(data.iloc[:100, 0], data.iloc[:100, 2])
    plt.xlim(410, 445)
    plt.subplot(3, 2, 2)
    plt.title('原始数据')
    plt.plot(data.iloc[:100, 0], data.iloc[:100, 2])
    plt.xlim(410, 445)
    plt.subplot(3, 2, 3)
    plt.title('RU')
    plt.plot(data_ru.iloc[:100, 0], data_ru.iloc[:100, 2])
    plt.xlim(410, 445)
    plt.subplot(3, 2, 4)
    plt.title('CNN')
    plt.plot(data_cnn.iloc[:100, 0], data_cnn.iloc[:100, 2])
    plt.xlim(410, 445)
    plt.subplot(3, 2, 5)
    plt.title('ENN')
    plt.plot(data_enn.iloc[:100, 0], data_enn.iloc[:100, 3])
    plt.xlim(410, 445)
    plt.subplot(3, 2, 6)
    plt.title('TL')
    plt.plot(data_tl.iloc[:100, 0], data_tl.iloc[:100, 3])
    plt.xlim(410, 445)
    plt.tight_layout()
    plt.show()
