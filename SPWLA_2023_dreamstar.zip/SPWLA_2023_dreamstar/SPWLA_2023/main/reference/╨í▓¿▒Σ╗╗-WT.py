# -*- coding: utf-8 -*-
# @Time    : 2023/5/13 22:22
# @Author  : Dreamstar
# @File    : 小波变换-wavelet transform.py
# @Desc    : wavelet transform的相关内容  pip install PyWavelets
# @Link    : https://blog.csdn.net/abc1234abcdefg/article/details/123517320
# @Link    : https://blog.csdn.net/weixin_46713695/article/details/127049520
# @Link    : https://blog.csdn.net/weixin_42341666/article/details/107026123
import math

import pandas as pd
import pywt
import matplotlib.pyplot as plt
import numpy as np
from pywt import wavedec
import statsmodels.api as sm
from statsmodels.tsa.ar_model import AR
from statsmodels.tsa.arima_model import ARIMA
from statsmodels.tsa.arima_model import ARMA


# # 小波
# sampling_rate = 1024
# t = np.arange(0, 1.0, 1.0 / sampling_rate)
# f1 = 100
# f2 = 200
# f3 = 300
# f4 = 400
# data = np.piecewise(t, [t < 1, t < 0.8, t < 0.5, t < 0.3],
#                     [lambda t: 400*np.sin(2 * np.pi * f4 * t),
#                      lambda t: 300*np.sin(2 * np.pi * f3 * t),
#                      lambda t: 200*np.sin(2 * np.pi * f2 * t),
#                      lambda t: 100*np.sin(2 * np.pi * f1 * t)])
# wavename = 'cgau8'
# totalscal = 256
# fc = pywt.central_frequency(wavename)
# cparam = 2 * fc * totalscal
# scales = cparam / np.arange(totalscal, 1, -1)
# [cwtmatr, frequencies] = pywt.cwt(data, scales, wavename, 1.0 / sampling_rate)
# plt.figure(figsize=(8, 4))
# plt.subplot(211)
# plt.plot(t, data)
# plt.xlabel("t(s)")
# plt.title('shipinpu',  fontsize=20)
# plt.subplot(212)
# plt.contourf(t, frequencies, abs(cwtmatr))
# plt.ylabel(u"prinv(Hz)")
# plt.xlabel(u"t(s)")
# plt.subplots_adjust(hspace=0.4)
# plt.show()


def cancut(nums, cuts, target):
    sum = 0
    cnt = 0
    for num in nums:
        sum += num
        if sum > target:
            cnt = cnt + 1
            sum = num
        if cnt > cuts:
            return False
    return True


def split_array(nums, m):  # 最小最大化
    left = 0
    right = 0
    for num in nums:  # 取最大元素值和数组和
        left = max(left, num)
        right += num
    while left < right:
        mid = (left + right) / 2
        if cancut(nums, m - 1, mid):
            right = mid
        else:
            left = mid + 1
    return left




# aa = []
# for i in range(200):
#     aa.append(np.sin(0.3 * np.pi * i))
# for i in range(200):
#     aa.append(np.sin(0.13 * np.pi * i))
# for i in range(200):
#     aa.append(np.sin(0.05 * np.pi * i))
# y = aa
df = pd.read_csv("../data/train/aligned_well_01.csv")

x = df['DEPT'][1000:1500].values
y = df['RD'][1000:1500].values
print(y)
for i in range(len(y)):
    y[i] = round(math.log(y[i]), 2)

n = 3
print(y)
coeffs = wavedec(y, 'db1', level=n)

result = pywt.waverec(coeffs, 'db1')

fix, ax = plt.subplots(nrows=4, ncols=1, figsize=(15, 13))
ax[0].plot(x, result)
ax[0].set_title('orgin')

plt.show()

# DJ阈值
coeffs1 = coeffs
for i in range(1, n):
    sigma = np.std(coeffs1[i], ddof=1)
    derta = sigma * math.sqrt(2 * abs(math.log(len(coeffs1[i]))))
    coeffs1[i] = pywt.threshold(coeffs1[i], derta)
result_DJ = pywt.waverec(coeffs1, 'db1')

# 基于零均值正态分布的置信区间阈值
coeffs2 = coeffs
for i in range(1, n):
    sigma = np.std(coeffs2[i], ddof=0)
    derta = 3 * sigma
    coeffs2[i] = pywt.threshold(coeffs2[i], derta)
result_sigma3 = pywt.waverec(coeffs2, 'db1')  # 效果不好

# 最小最大化阈值
coeffs3 =coeffs
for i in range(1, n):
    derta = split_array(abs(coeffs3[i]), 100)
    derta = derta * 100 / len(coeffs3[i])
    coeffs3[i] = pywt.threshold(coeffs3[i], derta)
result_minMax = pywt.waverec(coeffs3, 'db1')

# #Tbayes阈值
# coeffs4 = coeffs
# sigma = np.std(coeffs[n], ddof=0)
# for i in range(1, n):
#     sigmai = np.std(coeffs[i], ddof=0)
#     derta = sigma * sigma / sigmai
#     coeffs4[i] = pywt.threshold(coeffs[i], derta)
# result_T = pywt.waverec(coeffs4, 'db1')



fix1, ax1 = plt.subplots(nrows=4, ncols=1, figsize=(15, 13))

# ax1[0].plot(result_y)
# ax1[0].set_title('orgin')
# ax1[1].plot(np.arange(len(coeffs[1])), coeffs[1])
# ax1[1].set_title('low')
# ax1[2].plot(np.arange(len(coeffs[2])), coeffs[2])
# ax1[2].set_title('mid')
# ax1[3].plot(np.arange(len(coeffs[3])), coeffs[3])
# ax1[3].set_title('high')

ax1[0].plot(x, result_sigma3)
ax1[0].set_title('result_sigma3')
ax1[1].plot(x, result_minMax)
ax1[1].set_title('result_minMax')
ax1[2].plot(x, result_DJ)
ax1[2].set_title('result_DJ')

plt.show()
