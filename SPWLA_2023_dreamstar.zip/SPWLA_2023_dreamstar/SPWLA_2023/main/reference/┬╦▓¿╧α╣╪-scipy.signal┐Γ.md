## 滤波相关-scipy.signal库

### 滤波器

[butter函数](https://blog.csdn.net/weixin_43956732/article/details/108500088)

```
scipy.signal.butter(N, Wn, btype=‘low’, analog=False, output=‘ba’, fs=None)
```

1. 巴特沃斯数字和模拟滤波器设计。

   设计一个Nth-order 数字或模拟巴特沃斯滤波器并返回滤波器系数。

2. 参数：

   N:滤波器的阶数

   Wn：归一化截止频率。计算公式Wn=2*截止频率/采样频率。（注意：根据采样定理，采样频率要大于两倍的信号本身最大的频率，才能还原信号。截止频率一定小于信号本身最大的频率，所以Wn一定在0和1之间）。当构造带通滤波器或者带阻滤波器时，Wn为长度为2的列表。

   btype : 滤波器类型{‘lowpass’, ‘highpass’, ‘bandpass’, ‘bandstop’}

   output : 输出类型{‘ba’, ‘zpk’, ‘sos’}

3. 返回值：

   b，a: IIR滤波器的分子（b）和分母（a）多项式系数向量。output='ba'

   z,p,k: IIR滤波器传递函数的零点、极点和系统增益. output= 'zpk'

   sos: IIR滤波器的二阶截面表示。output= 'sos'

[iirfilter()函数](https://vimsky.com/examples/usage/python-scipy.signal.iirfilter.html)

`scipy.signal.iirfilter(N, Wn, rp=None, rs=None, btype='band', analog=False, ftype='butter', output='ba', fs=None)`

1. 参数：

   N：过滤器的顺序。

   Wn：给出临界频率的标量或长度为 2 的序列。对于数字滤波器，Wn 的单位与 fs 相		  同。默认情况下，fs 为 2 half-cycles/sample，因此这些从 0 归一化为 1，其中 1 		  是奈奎斯特频率。 (因此 Wn 在 half-cycles /样本中。)对于模拟滤波器，Wn 是角		  频率(例如，rad/s)。

   rp： 对于切比雪夫和椭圆滤波器，提供通带中的最大纹波。 (D b)

   rs： 对于切比雪夫和椭圆滤波器，在阻带中提供最小衰减。 (D b)

   btype： {‘bandpass’, ‘lowpass’, ‘highpass’, ‘bandstop’}，可选过滤器的类型。默认   				为‘bandpass’。

   analog： 如果为 True，则返回模拟滤波器，否则返回数字滤波器。

   ftype： 要设计的 IIR 滤波器类型：Butterworth : ‘butter’、Chebyshev I : ‘cheby1’、			  Chebyshev II : ‘cheby2’、Cauer/elliptic: ‘ellip’、Bessel/Thomson: ‘bessel’

   output： {‘ba’, ‘zpk’, ‘sos’}，输出的过滤形式：

   ​			 	second-order sections (recommended): ‘sos’

   ​				 numerator/denominator (default) : ‘ba’

   ​				 pole-zero : ‘zpk’

   fs：数字系统的采样频率。

2. 返回值：

   b，a: IIR滤波器的分子（b）和分母（a）多项式系数向量。output='ba'

   z,p,k: IIR滤波器传递函数的零点、极点和系统增益. output= 'zpk'

   sos: IIR滤波器的二阶截面表示。output= 'sos'



### 滤波函数

[lfilter函数](https://wenku.baidu.com/view/d93fc79ecbd376eeaeaad1f34693daef5ef7133c.html?_wkts_=1683643496543&bdQuery=scipy.signal.lfilter%28%29)

`scipy.signal.lfilter(b, a, x, axis=-1, zi=None)`

1. 参数：

   b和 a：用于指定滤波器的系数

   x：需要滤波的信号

   axis：指定要滤波的维度，默认为-1

   zi：初始化的滤波器状态

2. 返回值：

   滤波后的信号

[filtfilt函数（含butter介绍）](https://blog.csdn.net/weixin_43956732/article/details/108500088)

`scipy.signal.filtfilt(b, a, x, axis=-1, padtype='odd', padlen=None, method='pad', irlen=None)`

1. 参数：

   b: 滤波器的分子系数向量

   a: 滤波器的分母系数向量

   x: 要过滤的数据数组。（array型）

   axis: 指定要过滤的数据数组x的轴

   padtype: 必须是“奇数”、“偶数”、“常数”或“无”。这决定了用于过滤器应用的填充信号的扩展类型。{‘odd’, ‘even’, ‘constant’, None}

   padlen：在应用滤波器之前在轴两端延伸X的元素数目。此值必须小于要滤波元素个数- 1。（int型或None）

   method：确定处理信号边缘的方法。当method为“pad”时，填充信号；填充类型padtype和padlen决定，irlen被忽略。当method为“gust”时，使用古斯塔夫森方法，而忽略padtype和padlen。{“pad” ，“gust”}

   irlen：当method为“gust”时，irlen指定滤波器的脉冲响应的长度。如果irlen是None，则脉冲响应的任何部分都被忽略。对于长信号，指定irlen可以显著改善滤波器的性能。（int型或None）

2. 返回值

   滤波后的数据数组

[medfit()函数](https://blog.csdn.net/qq_38251616/article/details/115426742)

`scipy.signal.medfilt(volume, kernel_size=None)`

1. 参数：

   volume： N维输入数组。
   kernel_size： 一个标量或元组，代表每个维度中中值滤波窗口的大小（即取多少个值的中值），默认值为3。

2. 返回值

   滤波后的数据

[savgol_filter()函数](https://blog.csdn.net/ximu__l/article/details/129179388)

`scipy.signal.savgol_filter(x, window_length, polyorder)`

1. 参数的含义：

   x：要滤波的信号

   window_length：窗口长度；取值为奇数且不能超过len(x)。它越大，则平滑效果越明显；越小，则更贴近原始曲线

   polyorder：多项式拟合的阶数。它越小，则平滑效果越明显；越大，则更贴近原始曲线

2. 返回值

   滤波后的数据

### 参考资料

[scipy.signal模块函数类型参考](https://www.codingdict.com/sources/py/scipy.signal.html)