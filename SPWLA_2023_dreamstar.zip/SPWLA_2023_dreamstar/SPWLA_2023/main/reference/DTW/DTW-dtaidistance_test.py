#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2023-05-04 09:37
# @Author  : Dreamstar
# @File    : dtaidistance_test.py
# @Desc    : 对dtaidistance第三方库的内容进行测试

# 0.简介
from dtaidistance import dtw
from dtaidistance import dtw_visualisation as dtwvis
import numpy as np
s1 = np.array([0., 0, 1, 2, 1, 0, 1, 0, 0, 2, 1, 0, 0])
s2 = np.array([0., 1, 2, 3, 1, 0, 0, 0, 2, 1, 0, 0, 0])
path = dtw.warping_path(s1, s2)
dtwvis.plot_warping(s1, s2, path, filename="warp.png")

# 1.1 distance-相似性度量-距离矩阵
# 常规方式
from dtaidistance import dtw
s1 = [0, 0, 1, 2, 1, 0, 1, 0, 0]
s2 = [0, 1, 2, 0, 0, 0, 0, 0, 0]
distance = dtw.distance(s1, s2)
print(distance)
# 可使用c进行加速，需要使用array形式作为输入(dtype double or float)
from dtaidistance import dtw
import array
s1 = array.array('d',[0, 0, 1, 2, 1, 0, 1, 0, 0])
s2 = array.array('d',[0, 1, 2, 0, 0, 0, 0, 0, 0])
d = dtw.distance_fast(s1, s2, use_pruning=True)

from dtaidistance import dtw
import numpy as np
s1 = np.array([0, 0, 1, 2, 1, 0, 1, 0, 0], dtype=np.double)
s2 = np.array([0.0, 1, 2, 0, 0, 0, 0, 0, 0], dtype=np.double)
d = dtw.distance_fast(s1, s2, use_pruning=True)

# 1.2 算法复杂度及微调
# 距离函数具有线性空间复杂度，但具有二次时间复杂度。
# 为降低时间复杂性，DTW允许设定最大偏移的窗口（也称为Sakoe Chiba频带）。
# 可将复杂性降低到窗口大小和最大序列长度的乘积：
'''
max_dist：避免计算大于此值的部分路径。如果没有找到小于或等于该值的解，则返回无穷大。
use_pruning：修剪部分路径，将max_dist设置为欧几里得上界。如果此选项设置为true，则会自动执行此操作。
max_step：不允许步长大于此值，超过则将其替换为无穷大。
max_length_diff：如果两个序列的长度差大于此值，则返回无穷大。
'''
# 一些微调方式
'''
penalty：(伸缩控制)惩罚，如果应用压缩或扩展（在距离的顶部），则要添加的惩罚。
psi：(起始控制)如果这会导致较低的距离，则可以忽略序列的起始点和结束点的数量。这也被称为psi弛豫（对于循环序列）。
'''
from dtaidistance import dtw
s1 = [0, 0, 1, 2, 1, 0, 1, 0, 0]
s2 = [0, 1, 2, 0, 0, 0, 0, 0, 0]
distance, paths = dtw.warping_paths(s1, s2)
print(distance)
print(paths)

from dtaidistance import dtw
from dtaidistance import dtw_visualisation as dtwvis
import random
import numpy as np
x = np.arange(0, 20, .5)
s1 = np.sin(x)
s2 = np.sin(x - 1)
random.seed(1)
for idx in range(len(s2)):
    if random.random() < 0.05:
        s2[idx] += (random.random() - 0.5) / 2
d, paths = dtw.warping_paths(s1, s2, window=25, psi=2)  # 这里的paths为累积距离矩阵
best_path = dtw.best_path(paths)
dtwvis.plot_warpingpaths(s1, s2, paths, best_path)

# 1.3 多时间序列的DTW - dtw.distance_matrix
# 输入序列可以是一个列表的arrays，或者是一个矩阵matrix,
# 使用parallel可并行计算,设置compact为true可只保存上三角矩阵
from dtaidistance import dtw
import numpy as np
timeseries = [
    np.array([0, 0, 1, 2, 1, 0, 1, 0, 0], dtype=np.double),
    np.array([0.0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0]),
    np.array([0.0, 0, 1, 2, 1, 0, 0, 0])]
ds = dtw.distance_matrix_fast(timeseries)

# DTW between multiple time series, limited to block

# DTW based on shape

# 旧内容的备份
# ############# dtaidistance-1 ####################
# path01 = r"D:\python\git\gitee\SPWLA_2023\main\data\train\aligned_well_01.csv"
# path010 = r"D:\python\git\gitee\SPWLA_2023\main\data\process\aligned_well_01_1.csv"
# df_data01 = pd.read_csv(path01)
# df_data010 = pd.read_csv(path010)
#
# df_data01 = df_data01['RHOB'][100:300]
# df_data010 = df_data010['RHOB'][100:300]
#
# arr_x01 = df_data01.values
# arr_x010 = df_data010.values
#
# path = dtw.warping_path(arr_x01, arr_x010)
# dtwvis.plot_warping(arr_x01, arr_x010, path, filename="warp-1.png")
# plt.show()
# ############# dtaidistance-2 ####################
# x = np.arange(0, 20, .5)
# s1 = np.sin(x)
# s2 = np.sin(x - 1)
# d, paths = dtw.warping_paths(s1, s2, window=25, psi=2)
# best_path = dtw.best_path(paths)
# dtwvis.plot_warpingpaths(s1, s2, paths, best_path, filename="warp-1.png")
#
# ############## 官方教程 ######################
# from dtwalign import dtw
# from dtwalign import dtw_from_distance_matrix
#
# val_well = pd.read_csv('../data/stretch/aligned_well_01_strech_1.csv')
# Y_feat = ['RHOB', 'NPHI', 'RD']
# val_well['wellnum'] = '01'
# dfs_val = dict(tuple(val_well.groupby('wellnum')))
# N = 101
# for well in list(dfs_val.keys()):
#     for mykey in Y_feat:
#         ref = dfs_val[well][f'{mykey}_pred'].values
#         query = dfs_val[well][f'{mykey}'].values
#
#         # ref_mean = np.convolve(ref, np.ones(N) / N, mode='same')
#         # query_mean = np.convolve(query, np.ones(N) / N, mode='same')
#         #
#         # ref2_mean = np.convolve((ref - ref_mean) ** 2, np.ones(N) / N, mode='same')
#         # query2_mean = np.convolve((query - query_mean) ** 2, np.ones(N) / N, mode='same')
#         #
#         # ref_norm = (ref - ref_mean) / ref2_mean
#         # query_norm = (query - query_mean) / query2_mean
#
#         query = (query - query.mean()) / query.std() * ref.std() + ref.mean()
#         #     loss_matrix=(query.reshape(1,-1)-ref.reshape(-1,1))**2
#         alignmentOBE = dtw(query, ref,
#                            step_pattern="asymmetric",  # dist=lambda x, y: 10000000-x*y,
#                            window_type="sakoechiba", window_size=201)
#         mypath = alignmentOBE.get_warping_path(target="reference")
#         dfs_val[well][f'{mykey}_dept_pred'] = dfs_val[well]['DEPT'].values[mypath]
#
#         f = interpolate.interp1d(
#             dfs_val[well]['DEPT'].values[mypath] + 0.0000001 * np.arange(dfs_val[well]['DEPT'].values.size),
#             dfs_val[well][f'{mykey}'].values,
#             fill_value=(dfs_val[well][f'{mykey}'].values[0], dfs_val[well][f'{mykey}'].values[-1]),
#             bounds_error=False, kind=1)
#         dfs_val[well][f'{mykey}_dtw'] = f(dfs_val[well]['DEPT'].values)
#
#         plt.figure()
#         plt.plot(dfs_val[well]['DEPT'].values, dfs_val[well][f'{mykey}'].values, alpha=0.5, label='Truth log')
#         plt.plot(dfs_val[well]['DEPT'].values, dfs_val[well][f'{mykey}_dtw'].values, alpha=0.5, label='Predict log')
#         plt.plot(dfs_val[well][f'{mykey}_dept_pred'].values, dfs_val[well][f'{mykey}'].values, alpha=0.5,
#                  label='Aligned log')
#         plt.legend()
#         plt.show()
#
# ########## 下面是关于绘图的函数 ##############
# ########## 临时放置的绘图函数 ###############
# def plot_warping(s1, s2, path, filename=None, fig=None, axs=None,
#                  series_line_options=None, warping_line_options=None):
#     """Plot the optimal warping between to sequences.
#
#     :param s1: From sequence.
#     :param s2: To sequence.
#     :param path: Optimal warping path.
#     :param filename: Filename path (optional).
#     :param fig: Matplotlib Figure object
#     :param axs: Array of Matplotlib axes.Axes objects (length == 2)
#     :param series_line_options: Dictionary of options to pass to matplotlib plot
#         None will not pass any options
#     :param warping_line_options: Dictionary of options to pass to matplotlib ConnectionPatch
#         None will use {'linewidth': 0.5, 'color': 'orange', 'alpha': 0.8}
#     :return: Figure, list[Axes]
#     """
#     try:
#         import matplotlib.pyplot as plt
#         import matplotlib as mpl
#         from matplotlib.patches import ConnectionPatch
#     except ImportError:
#         raise ImportError("The plot_warp function requires the matplotlib package to be installed.")
#     if fig is None and axs is None:
#         fig, axs = plt.subplots(nrows=2, ncols=1, sharex='all', sharey='all')
#     elif fig is None or axs is None:
#         raise TypeError(f'The fig and axs arguments need to be both None or both instantiated.')
#     if series_line_options is None:
#         series_line_options = {}
#     axs[0].plot(s1, **series_line_options)
#     axs[1].plot(s2, **series_line_options)
#     plt.tight_layout()
#     lines = []
#     if warping_line_options is None:
#         warping_line_options = {'linewidth': 0.5, 'color': 'orange', 'alpha': 0.8}
#     for r_c, c_c in path:
#         if r_c < 0 or c_c < 0:
#             continue
#         con = ConnectionPatch(xyA=[r_c, s1[r_c]], coordsA=axs[0].transData,
#                               xyB=[c_c, s2[c_c]], coordsB=axs[1].transData, **warping_line_options)
#         lines.append(con)
#     for line in lines:
#         fig.add_artist(line)
#     if filename:
#         plt.savefig(filename)
#         plt.close()
#     return fig, axs
#
# ########### 0502-mf-查看并调用dtaidistance中的plot方法 #####################
# import os
# import logging
# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt
# from dtaidistance import dtw
# from dtaidistance import dtw_visualisation as dtwvis
# # from . import util_numpy
# # 0.数据准备
# path01 = r"D:\python\git\gitee\SPWLA_2023\main\data\train\aligned_well_01.csv"
# path010 = r"D:\python\git\gitee\SPWLA_2023\main\data\train\aligned_well_010.csv"
# data01 = pd.read_csv(path01)
# data010 = pd.read_csv(path010)
# # 0.数据准备 截取部分长度-选RHOB曲线测试
# data01 = data01[0:100]
# data010 = data010[0:100]
# df_data01 = data01['RHOB']
# df_data010 = data010['RHOB']
# arr_x01 = df_data01.values
# arr_x010 = df_data010.values
# # 0.数据准备 - dtw计算获得路径
# path: list = dtw.warping_path(arr_x01, arr_x010)
# # 1. 绘制原始序列和目标序列的关系
# # dtwvis.plot_warping(from_s=, to_s, new_s, path, filename=None, fig=None, axs=None)  # 原始函数
# fig, _ = plot_warping(arr_x01, arr_x010, path, filename="warp.png")
# # # 2.绘制整体的累积成本矩阵，查看所有可能的扭曲路径
# # # psi参数: 可以放松对开始和结束处的匹配。在这个例子中，即使正弦波稍微偏移，也会完美匹配。
# # s1 = df_data01.values
# # s2 = df_data010.values
# # d, paths = dtw.warping_paths(s1, s2, window=25, psi=2)
# # best_path = dtw.best_path(paths)
# # dtwvis.plot_warpingpaths(s1, s2, paths, best_path, filename="warp-1.png",)
#
#
# # 使用官方包的话，需要把path的形式调整一下
# from dtwalign import dtw
# alignmentOBE = dtw(arr_x01, arr_x010,
#                    step_pattern="asymmetric",  # dist=lambda x, y: 10000000-x*y,
#                    window_type="sakoechiba", window_size=201)
# # target 对画图的结果有较大的影响 "query" or "reference" # 官方参考使用的是reference
# mypath = alignmentOBE.get_warping_path(target="query")
# path_list = mypath.tolist()
# index_list = list(range(len(path_list)))
# path = zip(path_list, index_list)  # 目前只实现了单向的
# plot_warping(arr_x01, arr_x010, path, filename="warp-1.png")
# pass