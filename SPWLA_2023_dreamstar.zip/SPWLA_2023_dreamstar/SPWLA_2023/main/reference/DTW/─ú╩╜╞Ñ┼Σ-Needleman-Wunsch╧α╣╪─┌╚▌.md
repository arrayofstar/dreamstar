## Needleman-Wunsch相关内容

尼德曼-翁施算法（Needleman-Wunsch Algorithm）是基于生物信息学的知识来匹配蛋白序列或者DNA序列的（序列对比）算法。按照惩罚因子构建得分矩阵，求出匹配路径。

目前已知关于NW算法的库有：[dtaidistance.alignment](https://dtaidistance.readthedocs.io/en/latest/usage/dtw.html)、[nwalign](https://pypi.org/project/nwalign/)、Bio

算法实现流程：

- 计算得分矩阵-scores
- 回溯寻找匹配路径矩阵、计算得分（最后两个匹配的数据的得分）-paths、value
- 根据回溯路径输出匹配结果

### dtaidistance.alignment

```python
alignment.needleman_wunsch(s1, s2, window=None,                                                    max_dist=None,max_step=None,                                      max_length_diff=None,psi=None,substitution=None)
```
1. Needleman-Wunsch全局序列比对。
2. 参数：
   - s1, s2：对比序列
   - window：
   - max_dist：如果距离超过此值，则停止规整路径。
   - max_step：如果最后一次增量超过此值，则停止规整路径。
   - max_length_diff：如果两个序列的长度不同，则退出。
   - psi：
   - substitution：对于Needleman Wunsch，使用的默认函数：对于匹配为-1，对于不匹配为+1。如果有自定义的距离值，则可以使用`make_substitution_fn`从字典中生成函数的方法。

```
best_alignment(paths, s1=None, s2=None, gap="-", order=None)
```
1. 根据路径矩阵计算最佳对齐路径。
2. 参数：
   - paths：路径矩阵。
   - s1, s2：对比序列
   - gap：间隔符号
   - order：回溯出现多条路径时的优先选择方向，默认0（对角线），1（向上），2（向左）。
```
make_substitution_fn(matrix, gap=1, opt='max')
```
1. 传入字典构造一个相似函数。
2. 参数：
   - matrix：把矩阵置换成一个元组字典。原文：“Substitution matrix as a dictionary of tuples to values.”
   - gap：
   - opt：选取各路径来源的得分方法，默认最大值。




### 参考链接

1. [dtaidistance.alignment](https://dtaidistance.readthedocs.io/en/latest/usage/sequence.html)
2. [Bio教程1](https://www.osgeo.cn/biopython/Bio.Align.Applications.html#Bio.Align.Applications.MuscleCommandline)
3. [Bio教程2](https://blog.csdn.net/weixin_26713521/article/details/108134072)
4. [Bio教程3](http://doc.yonyoucloud.com/doc/Biopython-cn/index.html)
5. [Bio教程4](https://www.yiibai.com/biopython/)
6. [nwalign](https://pypi.org/project/nwalign/)
7. [nwalign(中文)](https://www.cnpython.com/pypi/nwalign)

