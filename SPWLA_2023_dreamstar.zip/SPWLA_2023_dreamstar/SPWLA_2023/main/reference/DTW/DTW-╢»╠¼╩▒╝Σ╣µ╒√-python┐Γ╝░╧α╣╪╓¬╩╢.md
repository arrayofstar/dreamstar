## DTW相关内容

动态时间规整（Dynamic Time Warping, 简称DTW），按照距离最近的原则，构建两个序列元素之间的对应关系，并且可以评估两个序列的相似性。其算法特征如下：

- 单向对应，不能回头
- 一一对应，不能有空
- 对应之后，距离最近

目前已知关于DTW的库有：[dtaidistance](https://dtaidistance.readthedocs.io/en/latest/usage/dtw.html)、[dtwalign](https://dtwalign.readthedocs.io/en/latest/features.html)、fastdtw、tslearn（后面可继续添加）

算法实现流程：

- 计算累计距离矩阵-distance(输出)
- 寻找配准路径-step pattern(输入参数)
- 输出配准结果-path(输出)

### dtaidistance特点

- 可以**绘制点对应图**(**重点**)

- 可以实现多序列之间的聚类匹配(Clustering)

- 可以**搜索子序列**在目标序列中的最佳匹配(**Subsequence**)

- 可以实现**Needleman-Wunsch**序列比对

- 其他，实现了C的加速计算，

  ```
  输入数据:
  	s1:原始序列，query
  	s2:参考序列，reference
  dtw.warping_path(s1, s2)：返回对齐后对应的path(s1,s2)元组；
  dtw.warping_paths(s1, s2)：返回距离和路径矩阵；更多参数查看print(dtw.warping_paths.__doc__)；
  dtw.distance(s1, s2)：计算序列间的距离；更多参数查看print(dtw.distance.__doc__)；
  dtw.distance_fast(s1, s2)：与distance相同，但用来选择基于C的快速版本，此属性应该用double类型数组，如：numpy.array([1，2，3]，dtype=numpy.bdouble)或array.array('d'，[1，2，3])作为s1、s2；
  dtw.best_path(paths)：输入路径矩阵，输出最佳路径；
  dtw.distance_matrix(timeseries, block, compact)：多重时间序列，返回序列间的路径矩阵，block：？？，compact：？？；
  distance_matrix_fast(timeseries)：distance_matrix快速版本；
  
  模块：
  dtw_visualisation：
  	dtw_visualisation.plot_warping(s1, s2, path, filename="warp.png")：依据绘制两条曲线的相似序列对应图；
  	dtwvis.plot_warpingpaths(s1, s2, paths, best_path)：绘制热力图。
  dtw_ndim：
  	dtw_ndim.distance(series1, series2)：计算多元序列距离。
  	
  ```

#### 补充

- dtw.distance(s1, s2)参数（同dtw.warping_paths(s1, s2)）：
  - window：只允许从小于这个数字的两条对角线进行最大偏移。包括对角线，意味着通过设置window=1可以获得欧几里得距离。
  - max_dist: 如果返回的值将大于此值，则停止。
  - **max_step**：不允许步长大于此值。
  - max_length_diff：如果两个序列的长度较大，则返回无穷大
  - **penalty**：应用压缩或扩展时要添加的惩罚

### dtwalign特点

- 可绘制对齐路径可视化的**热力图**
- 可对寻找配准路径时的**step pattern**进行定义（Symmetric2、AsymmetricP2、TypeIVc）
- 可添加全局的窗口约束**windowing**（Sakoechiba、Itakura、User defined）
- 可**直接获得**DTW之后的对齐数据

```
1.dtw(x, y, dist="euclidean", window_type="none", window_size=None, step_pattern="symmetric2", dist_only=False, open_begin=False, open_end=False)

参数：
x（1D or 2D array）：reference（模板）序列；
y（1D or 2D array）：query（查询）序列；
window_type（string）：全局条件约束，有："Sakoechiba"、"Itakura"、"User defined"；
window_size（int）：窗口大小；
step_pattern（string）：点之间的匹配模式;
open_end和open_begin（bool）：设为True表示无拘束的匹配，即完全的部分匹配，默认是全局匹配，就是严格对应头和尾;
dist（string or callable）：距离公式，默认欧几里得公式，可以通过lambda自定义公式，也可参考scipy.spatial.distance.cdist；
dist_only（bool）：是否获得路径。如果为true，则仅计算对齐距离，不获得路径。

属性：
get_warping_path(target="query")：获取路径，target："query"、"reference"；
res.plot_path(with_="cum")：绘制热力图，with_："cum"展示热力图背景、"win"不展示热力图背景;
plot_pattern：绘制默认步长模式图。
```

### 目前需要做的事儿

- 编写三个函数，分别对应训练(计算累积距离矩阵、获得best_path)、预测(使用best_path将query根据ref进行校正)、绘图(绘制前后的对比图和连线)
- align_dtw(query, reference, dis_function=None, windows=None, step_pattern=None): Return `distance, dis_matrix,(齐前三个返回值暂时不需要)`。path, align_query: list/array
- plot_dtw(query, reference, path)

### 参考链接

这里先放一个示例

1. [python分别使用dtw、fastdtw、tslearn、dtaidistance四个库计算dtw距离，哪个计算速度最快？](https://blog.csdn.net/shiyuzuxiaqianli/article/details/115420168)
2. [dtwalign官网介绍](https://dtwalign.readthedocs.io/en/latest/tutorial.html)
3. [dtaidistance官方介绍](https://dtaidistance.readthedocs.io/en/latest/usage/dtw.html#dtw-distance-measure-between-two-time-series)

****













