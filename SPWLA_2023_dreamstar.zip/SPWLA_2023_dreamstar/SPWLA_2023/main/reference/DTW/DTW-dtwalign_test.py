# -*- coding: utf-8 -*-
# @Time    : 2023/5/3 22:45
# @Author  : Dreamstar
# @File    : dtwalign_test.py.py
# @Desc    : 对第三方库进行测试


import numpy as np
import matplotlib.pyplot as plt

np.random.seed(1234)
# generate toy data
x = np.sin(2 * np.pi * 3.1 * np.linspace(0, 1, 101))
x += np.random.rand(x.size)
y = np.sin(2 * np.pi * 3 * np.linspace(0, 1, 120))
y += np.random.rand(y.size)

# plt.plot(x, label="query")
# plt.plot(y, label="reference")
# plt.legend()
# plt.ylim(-1, 3)

from dtwalign import dtw
res = dtw(x, y)
# 1. 计算距离矩阵-判断相似性
# 设置distance_only参数可以只计算distance
print("dtw distance: {}".format(res.distance))
# dtw distance: 30.048812654583166
print("dtw normalized distance: {}".format(res.normalized_distance))
# dtw normalized distance: 0.13596747807503695

# 2.对齐路径
# 绘图
# res.plot_path(with_="win")
# res.plot_path(with_="cum")
# 对齐路径path
path = res.path
x_path = res.path[:, 0]
y_path = res.path[:, 1]

# warp x to y
x_warping_path = res.get_warping_path(target="query")
plt.plot(x[x_warping_path], label="aligned query to reference")
plt.plot(y, label="reference")
plt.legend()
plt.ylim(-1, 3)
plt.show()

# warp y to x
y_warping_path = res.get_warping_path(target="reference")
plt.plot(x, label="query")
plt.plot(y[y_warping_path], label="aligned reference to query")
plt.legend()
plt.ylim(-1, 3)
plt.show()

# 3.全局约束
# run DTW with Itakura constraint
res = dtw(x, y, window_type="itakura")
res.plot_path()

# run DTW with Sakoechiba constraint
res = dtw(x, y, window_type="sakoechiba", window_size=20)
# visualize alignment path with cumsum cost matrix
res.plot_path()

# 局部约束 - 对step pattern参数
'''
symmetric1
symmetric2
symmetricP05
symmetricP0
symmetricP1
symmetricP2
Asymmetric
AsymmetricP0
AsymmetricP05
AsymmetricP1
AsymmetricP2
TypeIa
TypeIb
TypeIc
TypeId
TypeIas
TypeIbs
TypeIcs
TypeIds
TypeIIa
TypeIIb
TypeIIc
TypeIId
TypeIIIc
TypeIVc
Mori2006
'''

# run DTW with symmetricP2 pattern
res = dtw(x, y, step_pattern="symmetricP2")
res.plot_path()

# 4.部分对齐 - Partial alignment
# 通过设置open_begin和open_end来达到序列中部分对齐的效果

x_partial = np.sin(2 * np.pi * 3 * np.linspace(0.3, 0.8, 100))
x_partial += np.random.rand(x_partial.size)
y_partial = np.sin(2 * np.pi * 3.1 * np.linspace(0, 1, 120))
y_partial += np.random.rand(y_partial.size)

plt.plot(x_partial, label="query")
plt.plot(y_partial, label="reference")
plt.legend()
plt.ylim(-1, 3)
# 开放结尾
res = dtw(x_partial, y_partial, open_end=True)
res.plot_path()
# 开放开头
res = dtw(x_partial, y_partial, step_pattern="asymmetric", open_begin=True)
res.plot_path()
# 两端开放
res = dtw(x_partial, y_partial, step_pattern="asymmetric", open_begin=True, open_end=True)
res.plot_path()

# 5.其他的度量方式
# 可以使用其他的距离度量（默认为欧几里得），也可以自定义。支持scipy.spatial.distance.cdist中的度量：

# res = dtw(x, y, dist="minkowski")
# res = dtw(x, y, dist=lambda x, y: np.abs(x - y))

# 进行到了这里
