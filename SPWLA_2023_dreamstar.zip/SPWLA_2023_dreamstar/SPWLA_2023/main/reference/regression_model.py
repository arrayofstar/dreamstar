# -*- coding: utf-8 -*-
# @Time    : 2023/4/25 09:19
# @Author  : YYY
# @File    : regression model.py
# @Desc    : 回归算法
# @Link    : [1] https://zhidao.baidu.com/question/1835457060130519020.html NMSE计算方法

from math import sqrt

# 调用库
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import ElasticNet
from sklearn.linear_model import LassoCV
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge
from sklearn.linear_model import SGDRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from xgboost import XGBRegressor
import joblib


def Linear(x_train, y_train):
    """
    线性回归
    参数：
        x_train(DataFrame): 输入训练集自变量x数据
        y_train(DataFrame): 输入训练集因变量y数据
    返回：
        线性回归模型
    示例：
        Linear(x_train, y_RHOB_train)
    """
    lin_reg = LinearRegression()  # 还可以调参
    lin_reg.fit(x_train, y_train)
    return lin_reg


def Tree(x_train, y_train):
    """
    决策树
    参数：
        x_train(DataFrame): 输入训练集自变量x数据
        y_train(DataFrame): 输入训练集因变量y数据
        x_test(DataFrame): 输入测试集自变量x数据
    返回：
        测试集预测y值结果
    示例：
        Tree(x_train, y_RHOB_train, x_test)
    """
    tree_reg = DecisionTreeRegressor(random_state=0)  ###############还可以调参
    tree_reg.fit(x_train, y_train)
    return tree_reg


def RF(x_train, y_train):
    """
    随机森林
    参数：
        x_train(DataFrame): 输入训练集自变量x数据
        y_train(DataFrame): 输入训练集因变量y数据
        x_test(DataFrame): 输入测试集自变量x数据
    返回：
        测试集预测y值结果
    示例：
        Rand(x_train, y_RHOB_train, x_test)
    """
    forest_reg = RandomForestRegressor(n_estimators=300, random_state=0)  ###############还可以调参,n_estimators为弱分类器个数
    forest_reg.fit(x_train, y_train)
    return forest_reg


def Lass(x_train, y_train):
    """
    lasso回归
    参数：
        x_train(DataFrame): 输入训练集自变量x数据
        y_train(DataFrame): 输入训练集因变量y数据
        x_test(DataFrame): 输入测试集自变量x数据
    返回：
        测试集预测y值结果
    示例：
        Lass(x_train, y_RHOB_train, x_test)
    """
    lasso = LassoCV()  ###############还可以调参
    lasso.fit(x_train, y_train)
    return lasso


def Rid(x_train, y_train):
    """
    岭回归
    参数：
        x_train(DataFrame): 输入训练集自变量x数据
        y_train(DataFrame): 输入训练集因变量y数据
        x_test(DataFrame): 输入测试集自变量x数据
    返回：
        测试集预测y值结果
    示例：
        Rid(x_train, y_RHOB_train, x_test)
    """
    rid = Ridge(alpha=5.0)  ###############还可以调参
    rid.fit(x_train, y_train)
    return rid


def Ela(x_train, y_train):
    """
    弹性网回归
    参数：
        x_train(DataFrame): 输入训练集自变量x数据
        y_train(DataFrame): 输入训练集因变量y数据
        x_test(DataFrame): 输入测试集自变量x数据
    返回：
        测试集预测y值结果
    示例：
        Ela(x_train, y_RHOB_train, x_test)
    """
    ela = ElasticNet(alpha=0.1, l1_ratio=0.5, fit_intercept=False)  ###############还可以调参
    ela.fit(x_train, y_train)
    return ela


def XGBoost(x_train, y_train):
    """
    XGBoost
    参数：
        x_train(DataFrame): 输入训练集自变量x数据
        y_train(DataFrame): 输入训练集因变量y数据
        x_test(DataFrame): 输入测试集自变量x数据
    返回：
        测试集预测y值结果
    示例：
        XGB(x_train, y_RHOB_train, x_test)
    """
    xg = XGBRegressor(n_estimators=1000, max_depth=7, eta=0.1, subsample=0.7,
                      colsample_bytree=0.8)  ###############还可以调参
    xg.fit(x_train, y_train)
    return xg


def Poly(x_train, y_train):
    """
    多项式回归
    参数：
        x_train(DataFrame): 输入训练集自变量x数据
        y_train(DataFrame): 输入训练集因变量y数据
        x_test(DataFrame): 输入测试集自变量x数据
    返回：
        测试集预测y值结果
    示例：
        Poly(x_train, y_RHOB_train, x_test)
    """
    poly_reg = PolynomialFeatures(degree=2)  # ##############还可以调参

    X_train_2d = poly_reg.fit_transform(x_train)
    X_test_2d = poly_reg.transform(x_test)

    lin_reg = LinearRegression()  # ##############还可以调参
    lin_reg.fit(X_train_2d, y_train)

    poly_reg.fit(X_train_2d, y_train)
    return [lin_reg, X_test_2d]


def SGD(x_train, y_train):
    """
    随机梯度下降算法
    参数：
        x_train(DataFrame): 输入训练集自变量x数据
        y_train(DataFrame): 输入训练集因变量y数据
        x_test(DataFrame): 输入测试集自变量x数据
    返回：
        测试集预测y值结果
    示例：
        SGD(x_train, y_RHOB_train, x_test)
    """
    sgd = SGDRegressor(n_iter_no_change=250, penalty=None, eta0=0.0001, max_iter=100000)  ###############还可以调参
    sgd.fit(x_train, y_train)
    return sgd


def SVM(x_train, y_train):
    """
    支持向量机
    参数：
        x_train(DataFrame): 输入训练集自变量x数据
        y_train(DataFrame): 输入训练集因变量y数据
        x_test(DataFrame): 输入测试集自变量x数据
    返回：
        测试集预测y值结果
    示例：
        SVM(x_train, y_RHOB_train, x_test)
    """
    svm = SVR(kernel='rbf', C=1000000, epsilon=0.001)  # ##############还可以调参
    svm.fit(x_train, y_train)
    return svm


def Loss(y_test, y_pred):
    """
    损失函数
    参数：
        y_test(DataFrame): 输入测试集因变量y数据
        y_pred(DataFrame): 输入测试集y预测结果
    返回：
        损失函数MAE、MSE、RMSE、R2
    示例：
        Loss(y_RHOB_test, y_pred)
    """
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    rmse = sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)
    print("mean_absolute_error:", mae)
    print("mean_squared_error:", mse)
    print("rmse:", rmse)
    print("r2 score:", r2)
    return [mae, mse, rmse, r2]


if __name__ == '__main__':
    path = r'../data/stretch/aligned_well_01_1_strech_1.csv'
    data = pd.read_csv(path)
    data = data.sample(n=5000)
    x = data.iloc[:, :5]
    y_RHOB = data.iloc[:, 5:11]
    x_train, x_test, y_RHOB_train, y_RHOB_test = train_test_split(x, y_RHOB, test_size=0.3, random_state=1)
    # print(x_train.iloc[:, 0])

    # 标准化数据
    std = StandardScaler()
    std.fit_transform(x_train)
    std.transform(x_test)

    i = 0
    index = ['线性回归', '决策树', '随机森林', 'Lasso回归', '岭回归', '弹性网回归', 'XGBoost算法', '多项式回归',
             '随机梯度下降回归', '支持向量机']
    col = ['MAE', 'MSE', 'RMSE', 'R2']
    loss = [[] for i in range(len(index))]

    print("线性回归——————————————————————————————")
    # 保存
    joblib.dump(Linear(x_train, y_RHOB_train), '../checkpoints/Linear.pkl', compress=3)  # ##########还可以调参
    # 重载
    load = joblib.load('../checkpoints/Linear.pkl')
    # 预测
    y_pred = load.predict(x_test)
    loss[i] = Loss(y_RHOB_test, y_pred)
    i = i + 1

    print("决策树——————————————————————————————")
    # 保存
    joblib.dump(Tree(x_train, y_RHOB_train), '../checkpoints/Tree.pkl', compress=3)  # ##########还可以调参
    # 重载
    load = joblib.load('../checkpoints/Tree.pkl')
    # 预测
    y_pred = load.predict(x_test)
    loss[i] = Loss(y_RHOB_test, y_pred)
    i = i + 1

    print("随机森林——————————————————————————————")
    # 保存
    joblib.dump(RF(x_train, y_RHOB_train), '../checkpoints/RF.pkl', compress=3)  # ##########还可以调参
    # 重载
    load = joblib.load('../checkpoints/RF.pkl')
    # 预测
    y_pred = load.predict(x_test)
    loss[i] = Loss(y_RHOB_test, y_pred)
    i = i + 1

    # print("Lasso回归——————————————————————————————")
    # 保存
    # joblib.dump(Lass(x_train, y_RHOB_train), '../checkpoints/Lasso.pkl', compress=3)  # ##########还可以调参
    # 重载
    # load = joblib.load('../checkpoints/Lasso.pkl')
    # 预测
    # y_pred = load.predict(x_test)
    # loss[i] = Loss(y_RHOB_test, y_pred)
    # i = i + 1

    print("岭回归——————————————————————————————")
    # 保存
    joblib.dump(Rid(x_train, y_RHOB_train), '../checkpoints/Ridge.pkl', compress=3)  # ##########还可以调参
    # 重载
    load = joblib.load('../checkpoints/Ridge.pkl')
    # 预测
    y_pred = load.predict(x_test)
    loss[i] = Loss(y_RHOB_test, y_pred)
    i = i + 1

    print("弹性网回归——————————————————————————————")
    # 保存
    joblib.dump(Ela(x_train, y_RHOB_train), '../checkpoints/Ela.pkl', compress=3)  # ##########还可以调参
    # 重载
    load = joblib.load('../checkpoints/Ela.pkl')
    # 预测
    y_pred = load.predict(x_test)
    loss[i] = Loss(y_RHOB_test, y_pred)
    i = i + 1

    print("XGBoost——————————————————————————————")
    # 保存
    joblib.dump(XGBoost(x_train, y_RHOB_train), '../checkpoints/XGBoost.pkl', compress=3)  # ##########还可以调参
    # 重载
    load = joblib.load('../checkpoints/XGBoost.pkl')
    # 预测
    y_pred = load.predict(x_test)
    loss[i] = Loss(y_RHOB_test, y_pred)
    i = i + 1

    print("多项式回归——————————————————————————————")
    # 保存
    joblib.dump(Poly(x_train, y_RHOB_train)[0], '../checkpoints/Poly.pkl', compress=3)  # ##########还可以调参
    # 重载
    load = joblib.load('../checkpoints/Poly.pkl')
    # 预测
    y_pred = load.predict(Poly(x_train, y_RHOB_train)[1])
    loss[i] = Loss(y_RHOB_test, y_pred)
    i = i + 1

    # print("随机梯度下降回归——————————————————————————————")
    # 保存
    # joblib.dump(SGD(x_train, y_RHOB_train), '../checkpoints/SGD.pkl', compress=3)  # ##########还可以调参
    # 重载
    # load = joblib.load('../checkpoints/SGD.pkl')
    # 预测
    # y_pred = load.predict(x_test)
    # loss[i] = Loss(y_RHOB_test, y_pred)
    # i = i + 1

    # print("支持向量机——————————————————————————————")
    # 保存
    # joblib.dump(SVM(x_train, y_RHOB_train), '../checkpoints/SVM.pkl', compress=3)  # ##########还可以调参
    # 重载
    # load = joblib.load('../checkpoints/SVM.pkl')
    # 预测
    # y_pred = load.predict(x_test)
    # loss[i] = Loss(y_RHOB_test, y_pred)
    # i = i + 1

    loss = pd.DataFrame(loss, index=index, columns=col)
    # loss.to_csv(r'C:\Users\86183\Desktop\回归算法效果.csv',encoding='gbk')
    # 计算NMSE
    # loss['NMSE'] = loss['MSE'] / sum((y_RHOB_test - y_pred) ** 2)  # 如果是多变量任务的话，这里就不能这样算了-mf
    # loss.to_csv(r'C:\Users\86183\Desktop\回归算法NMSE.csv',encoding='gbk')
