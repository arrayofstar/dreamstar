# pywt模块使用

## 1、families

```
pywt.families(short=True)
返回软件内含的小波族。
12
```

- Parameters：   
  - short：是否简写
- Return：[list]   
  - [‘haar’, ‘db’, ‘sym’, ‘coif’, ‘bior’, ‘rbio’, ‘dmey’, ‘gaus’, ‘mexh’, ‘morl’, ‘cgau’, ‘shan’, ‘fbsp’, ‘cmor’]

## 2、wavelist

```
pywt.wavelist(family=None, kind='all')
返回该小波族（family）中包含的小波名称。
12
```

Parameters：

- family：简写小波族名称。如果为默认的None，则返回所有的小波名称。
- kind：’all’、’continuous’、’discrete’（离散或连续小波）

```python
>>> pywt.wavelist('coif')
['coif1', 'coif2', 'coif3', 'coif4', 'coif5', 'coif6', 'coif7', ...
>>> pywt.wavelist(kind='continuous')
['cgau1', 'cgau2', 'cgau3', 'cgau4', 'cgau5', 'cgau6', 'cgau7', ...
1234
```

## 3、Wavelet

```
(class) pywt.Wavelet(name, filter_bank=None)
描述由指定的小波名称标识的离散小波的性质的一个类（创建小波对象）。
12
```

Parameters：

- name：小波名称
- filter_bank：使用用户提供的滤波器组

## 4、wavefun

```
wavelet.wavefun()
在给定的分解阶次上依据小波系数近似给出尺度函数（phi）和小波函数（psi）。
12
对于正交小波：
>>> import pywt
>>> wavelet = pywt.Wavelet(‘db2′)
>>> phi, psi = wavelet.wavefun(level=5)
1234
```

## 5、central_frequency

```
pywt.central_frequency(wavelet, precision=8)
计算小波函数的中心频率。
12
```

Parameters：

- wavelet：小波实例（str、tuple）
- precision：用wavefun计算的用于小波函数逼近的精度(level=precision)

## 6、cwt

```
pywt.cwt(data, scales, wavelet)
连续小波变换
12
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201119152614917.gif#pic_center)

- Parameters:   
  - data : array_like， 信号数组
  - scales : 要使用的小波尺度（s）。
     可以用 *f = scale2frequency(wavelet, scale)/sampling_period 来确定物理频率大小。f的单位是赫兹，采样周期的单位为秒。
  - wavelet : Wavelet 对象或名字
  - sampling_period : float
     频率输出的采样周期。coefs的计算值与sampling_period的选择无关。scales不按抽样周期进行缩放。
  - axis: int, optional
     计算CWT的轴。如果不给出，则使用最后一个轴。
- Returns:   
  - coefs : array_like，
     给定尺度和小波的输入信号的连续小波变换。第一维是scales，其余为data
  - frequencies : array_like。
     如果采样周期的单位是秒，那么频率的单位是赫兹。否则，假设采样周期为1。

## 7、[dwt](https://pywavelets.readthedocs.io/en/latest/ref/dwt-discrete-wavelet-transform.html?highlight=dwt)

```
pywt.dwt(data, wavelet, mode='symmetric', axis=-1)
单层离散小波变换
12
```

- Parameters:

  - data : array_like
     输入信号数组
  - wavelet : Wavelet 对象或名字
  - mode : str, optional（默认’symmetric’）
     信号扩展模式（[mode详解](https://pywavelets.readthedocs.io/en/latest/ref/signal-extension-modes.html#ref-modes)）
     [‘zero’, ‘constant’, ‘symmetric’, ‘periodic’, ‘smooth’, ‘periodization’, ‘reflect’, ‘antisymmetric’, ‘antireflect’]
  - axis: int, optional
     计算DWT的轴。如果不给出，则使用最后一个轴。

- Returns: (cA, cD) : tuple
   近似分量，细节分量

- 注：

  - 系数数组的长度取决于所选模式。

    对于除periodization以外的所有模式：

    > len(cA) == len(cD) == floor((len(data) + wavelet.dec_len - 1) / 2)

    对于periodization模式

    > len(cA) == len(cD) == ceil(len(data) / 2)

- Examples

```python
>>> import pywt
>>> (cA, cD) = pywt.dwt([1, 2, 3, 4, 5, 6], 'db1')
>>> cA
array([ 2.12132034,  4.94974747,  7.77817459])
>>> cD
array([-0.70710678, -0.70710678, -0.70710678])
123456
```

- Wavelets families

  >>>import pywt

  >>>print pywt.families

  即可显示软件内含的小波族：

  [‘haar’, ‘db’, ‘sym’, ‘coif’, ‘bior’, ‘rbio’, ‘dmey’]

  它们分别是：

  l         Haar (haar)

  l         Daubechies (db)

  l         Symlets (sym)

  l         Coiflets (coif)

  l         Biorthogonal (bior)

  l         Reverse biorthogonal (rbio)

  l         “Discrete” FIR approximation of Meyer wavelet (dmey)


  2.2  wavelist（）

  >>> import pywt
  >>> print pywt.wavelist(‘coif’)
  >>> [‘coif1′, ‘coif2′, ‘coif3′, ‘coif4′, ‘coif5′]

  该方法显示该小波族中包含的小波名称。


  2.3  wave object

  创建小波对象：Wavelet(name, filter_bank=None)

  name：

      小波名称

  filter_bank:

      使用用户提供的滤波器组。该滤波器组必须实现:

  (dec_lo, dec_hi, rec_lo,rec_hi) =get_filters_coeffs()方法.

  dec_lo,dec_hi:

      分解滤波器值

  rec_lo,rec_hi:

      重构滤波器值

  dec_len:

      分解滤波器长度

  rec_len:

      重构滤波器长度

  其他属性：

  .family_name

  .short_name

  .orthogonal

  .biorthogonal

  .symmetry

  .vanishing_moments_psi

  .vanishing_moments_phi

  示例：

  >>> import pywt
  >>> wavelet = pywt.Wavelet(‘db1′)
  >>> print wavelet
  >>> Wavelet db1
  >>>     Family name:    Daubechies
  >>>       Short name:     db
  >>>       Filters length: 2
  >>>       Orthogonal:     True
  >>>       Biorthogonal:   True
  >>>       Symmetry:       asymmetric
  >>> print wavelet.dec_lo, wavelet.dec_hi
  >>> [0.70710678118654757, 0.70710678118654757] [-0.70710678118654757, 0.70710678118654757]
  >>> print wavelet.rec_lo, wavelet.rec_hi
  >>> [0.70710678118654757, 0.70710678118654757] [0.70710678118654757, -0.70710678118654757]

   


  2.4  wavefun()

  wavefun()方法可以在给定的分解阶次上依据小波系数近似给出尺度函数（phi）和小波函数（psi）。

  对于正交小波：

  >>> import pywt
  >>> wavelet = pywt.Wavelet(‘db2′)
  >>> phi, psi = wavelet.wavefun(level=5)

  对于双正交小波：

  >>> import pywt
  >>> wavelet = pywt.Wavelet(‘bior1.1′)
  >>> phi_d, psi_d, phi_r, psi_r = wavelet.wavefun(level=5)


  2.5  使用定制小波

  略


  3  离散小波变换（DWT）
  3.1  1D一阶dwt
  3.1.1  基本使用

  dwt()函数用于完成一阶、1D的离散小波变换。

  (cA, cD) = dwt(data, wavelet, mode=’sym’)

  data

           输入的信号可以是数值数组、python的list或其它可计数对象。如果数据不是double格式，则会被转成该格式。

  wavelet

           使用的小波的名称。可以是wavelist()中的，也可以是Wavelet对象的。

  mode

           信号拓展模式。见MODES。

  例1：

  ```
  >>> import pywt
  
  >>> x = [3, 7, 1, 1, -2, 5, 4, 6]
  
  >>> cA, cD = pywt.dwt(x, ‘db2′)
  
  >>> print cA
  
  [ 5.65685425  7.39923721  0.22414387  3.33677403  7.77817459]
  
  >>> print cD
  
  [-2.44948974 -1.60368225 -4.44140056 -0.41361256  1.22474487]
  
  >>> print pywt.idwt(cA, cD, ‘db2′)
  
  [ 3.  7.  1.  1. -2.  5.  4.  6.]
  ```

  例2：

  传递Wavelet对象时的用法：

  >>> w = pywt.Wavelet(‘sym3′)

  >>> cA, cD = pywt.dwt(x, wavelet=w, mode=’cpd’)

  >>> print cA

  [ 4.38354585  3.80302657  7.31813271 -0.58565539  4.09727044  7.81994027]

  >>> print cD

  [-1.33068221 -2.78795192 -3.16825651 -0.67715519 -0.09722957 -0.07045258]

  注意这里输出的系数数组长度不只跟输入数据的长度有关，还和Wavelet类型有关（特别是它所使用的滤波器长度）。如果想查看输出数据的长度可以使用dwt_coeff_len()函数：

  >>> pywt.dwt_coeff_len(data_len=len(x), filter_len=w.dec_len, mode=’sym’)

  6

  >>> pywt.dwt_coeff_len(len(x), w, ‘sym’)

  6

  >>> len(cA)

  6

  dwt_coeff_len（）函数的第三个参数是mode。

  >>> pywt.MODES.modes

  [‘zpd’, ‘cpd’, ‘sym’, ‘ppd’, ‘sp1′, ‘per’]

  >>> [pywt.dwt_coeff_len(len(x), w.dec_len, mode) for mode in pywt.MODES.modes]

  [6, 6, 6, 6, 6, 4]

  从这个例子可以看到，per（periodization）模式与其他的略有不同，它被设计为输出系数刚好是输入数据长度的一半。所以，当你在做DWT和IDWT的时候，不要把per模式和其他模式混合起来用。


  3.2.2  使用技巧

  用None做其中一个系数数组时，等效于给一个全零数组（两个数组中最多只能有一个None）：

  >>> print pywt.idwt([1,2,0,1], None, ‘db2′, ‘sym’)

  [ 1.19006969  1.54362308  0.44828774 -0.25881905  0.48296291  0.8365163 ]

  >>> print pywt.idwt([1, 2, 0, 1], [0, 0, 0, 0], ‘db2′, ‘sym’)

  [ 1.19006969  1.54362308  0.44828774 -0.25881905  0.48296291  0.8365163 ]

   

  >>> print pywt.idwt(None, [1, 2, 0, 1], ‘db2′, ‘sym’)

  [ 0.57769726 -0.93125065  1.67303261 -0.96592583 -0.12940952 -0.22414387]

  >>> print pywt.idwt([0, 0, 0, 0], [1, 2, 0, 1], ‘db2′, ‘sym’)

  [ 0.57769726 -0.93125065  1.67303261 -0.96592583 -0.12940952 -0.22414387]


  3.2.3         idwt中的系数长度。

  做IDWT变换时，通常两个系数数组长度必须相等。但是，在有些情况下，如多阶次的DWT和IDWT变换时，允许两者的数量少许不同会比较方便。当设置了correct_size标志时，逼近系数可以比细节系数大1：

  >>> print pywt.idwt([1, 2, 3, 4, 5], [1, 2, 3, 4], ‘db2′, ‘sym’, correct_size=True)

  [ 1.76776695  0.61237244  3.18198052  0.61237244  4.59619408  0.61237244]

   

  >>> print pywt.idwt([1, 2, 3, 4], [1, 2, 3, 4, 5], ‘db2′, ‘sym’, correct_size=True)

  Traceback (most recent call last):

  …

  ValueError: Coefficients arrays must satisfy (0 <= len(cA) – len(cD) <= 1).

  另外，要注意，不是所有的系数数组后可以使用IDWT，下面的例子所以失败，就是因为db4和sym模式的最小输出长度是4而不是3.

  >>> pywt.idwt([1,2,4], [4,1,3], ‘db4′, ‘sym’)

  Traceback (most recent call last):

  …

  ValueError: Invalid coefficient arrays length for specified wavelet. Wavelet and mode must be the same as used for decomposition.
  

```python

```