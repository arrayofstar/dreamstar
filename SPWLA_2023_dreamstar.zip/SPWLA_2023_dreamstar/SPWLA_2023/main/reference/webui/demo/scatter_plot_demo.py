"""
1、画图区间添加起点终点，
2、添加曲线预处理后与原始数据的和预测结果数据比较，
3、os实现文件选择(下拉框)
4、train函数实现开始训练按钮
"""

import gradio as gr
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.pyplot import MultipleLocator

filename = "E:\\桌面\\SPWLA_2023\\data\\test\\aligned_well_01.csv"
css = "footer {display: none !important;} .gradio-container {min-height: 0px !important};"

df = pd.read_csv(filename)
df = df[['DEPT', 'GR', 'RHOB', 'NPHI', 'RD']]
df = df.head(6921)
markers = ['o', 's', 'H', 'D']
colors = ['#e41a1c', '#377eb8', '#4daf4a', '#984ea3']
labels = ["GR", "RHOB", "NPHI", "RD"]


def line_draw(begining, end):
    """
        用于构造绘制原数据折线图数据格式及细节
        参数说明：begining和end分别是要绘制的测井深度的起点和终点
    """
    if begining > end:
        temp = begining
        begining = end
        end = temp
    interval = end - begining
    x_major_locator = MultipleLocator(interval / 20)  # 把x轴的刻度间隔设置为一个随区间变动的值，并存在变量里

    de = df[(df.DEPT >= begining) & (df.DEPT <= begining + interval)]
    de_melt = pd.melt(de, id_vars='DEPT', var_name='symbol', value_name='value')
    df1 = de_melt[de_melt.symbol == 'GR']
    df2 = de_melt[de_melt.symbol == 'RHOB']
    df3 = de_melt[de_melt.symbol == 'NPHI']
    df4 = de_melt[de_melt.symbol == 'RD']

    fig, ax = plt.subplots(nrows=5, ncols=1, sharex=True, figsize=(20, 10))
    fig.tight_layout(h_pad=0.3)

    ax[0].plot([], [])
    ax[0].spines[['left', 'right', 'top', 'bottom']].set_color('none')

    ax[1].plot(df1.DEPT, df1.value, color="red", linewidth=1, linestyle="-", label=labels[0])
    ax[1].set_ylabel(labels[0])
    ax[1].set_title('WELL DATA')
    ax[1].legend(loc='upper right', edgecolor='none', facecolor='none')
    ax[1].spines[['right', 'top']].set_color('none')
    ax[1].grid(axis='x', linestyle='--')
    ax[1].xaxis.set_major_locator(x_major_locator)

    # 把x轴的主刻度设置为10的倍数

    ax[2].plot(df2.DEPT, df2.value, color="blue", linewidth=1, linestyle="--", label=labels[1])
    ax[2].set_ylabel(labels[1])
    ax[2].legend(loc='upper right', edgecolor='none', facecolor='none')
    ax[2].spines[['right', 'top']].set_color('none')
    ax[2].grid(axis='x', linestyle='--')

    ax[3].plot(df3.DEPT, df3.value, color="green", linewidth=1, linestyle="-.", label=labels[2])
    ax[3].set_ylabel(labels[2])
    ax[3].legend(loc='upper right', edgecolor='none', facecolor='none')
    ax[3].spines[['right', 'top']].set_color('none')
    ax[3].grid(axis='x', linestyle='--')

    ax[4].plot(df4.DEPT, df4.value, color="black", linewidth=1, linestyle=":", label=labels[3])
    ax[4].set_yscale('log')
    ax[4].set_ylabel(labels[3])
    ax[4].set_xlabel('DEPT')
    ax[4].legend(loc='upper right', edgecolor='none', facecolor='none')
    ax[4].set_ylim(0, 10)
    ax[4].spines[['right', 'top']].set_color('none')
    ax[4].grid(axis='x', linestyle='--')
    return fig


css = "footer {display: none !important;} .gradio-container {min-height: 0px !important;}"

with gr.Blocks(css=css) as demo:
    gr.Markdown("预测结果可视化")
    with gr.Tab('parameter setting'):
        pass
    with gr.Tab("Origin Data"):
        with gr.Row():
            start = gr.Slider(800, 5000, 1000, interactive=True, label='Start')
            end = gr.Slider(800, 5000, 4000, interactive=True, label='End')
        btn = gr.Button(value='Run')
        output = gr.Plot()
        btn.click(line_draw, [start, end], output)
    with gr.Tab("Predict Data"):
        gr.Plot(value=plt)
    with gr.Tab("Data Increase"):
        pass

demo.launch()
