import math
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from PyEMD import EMD, Visualisation

t = np.linspace(0, 100, 100)
df = pd.read_csv("../data/train/aligned_well_01.csv")
y = df['GR'][1000:1500].values
x = df['DEPT'][1000:1500].values
plt.plot(y)
plt.show()

emd = EMD()
emd.emd(y)
imfs, res = emd.get_imfs_and_residue()
n = len(imfs)
fix, ax = plt.subplots(nrows=n+2, ncols=1, figsize=(25, 15))
i = 0
ax[i].plot(x, y)
ax[i].set_ylabel('orgin')
for j in range(n):
    i = i + 1
    ax[i].plot(imfs[j])
    ax[i].set_ylabel(f'imf{j+1}')
ax[n+1].plot(res)
ax[n+1].set_ylabel('res')
plt.tight_layout()
plt.show()
