# tsaug库相关介绍及内容

tsaug是一个用于时间序列数据增强的Python库，可以用于增强神经网络的训练数据，提高模型的鲁棒性和泛化能力。tsaug提供了多种数据增强技术，包括平移、旋转、缩放、添加噪声、剪切、裁剪、拉伸等。

使用tsaug非常简单，只需要定义一个数据增强管道（augmentation pipeline），将数据集中的每个样本传递给管道中进行增强处理即可。tsaug支持多种数据格式，包括numpy数组、pandas DataFrame、以及Python内置的列表等。

tsaug还支持自定义数据增强方法，只需要实现一个增强器类（augmenter class），并定义其apply方法即可。此外，tsaug还提供了一些方便的工具函数，例如数据集划分、可视化增强结果等。

总之，tsaug是一个非常方便易用的时间序列数据增强库，可以用于各种时间序列数据的增强处理，例如信号处理、语音识别、动作识别等等。

官方文档：

https://tsaug.readthedocs.io/en/stable/install.html

安装命令：

```python
pip install tsaug -i https://pypi.tuna.tsinghua.edu.cn/simple
```

## 快速入门

原始数据图像（取了一口井里面GR前100条数据）

![image-20230510150752451](tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510150752451.png)

### 1、tsaug.AddNoise

将随机噪声添加到时间序列中。

添加到时间序列的每个时间点的噪声是独立的并且是同分布的。

```
classtsaug.AddNoise(loc=0.0, scale=0.1, distr='gaussian', kind='additive', per_channel=True, normalize=True, repeats=1, prob=1.0, seed=None)
```

**Parameters**：

**loc**（浮点、列表或元组，可选）- Default: 0.0

随机噪声的平均值。

如果是float，则所有噪声值都以相同的平均值进行采样。

如果列表，则从具有从列表中随机选择的平均值的分布中采样添加到序列（如果per_channel为True，则为通道）的噪声。

如果是2元组，则从具有从区间中随机选择的平均值的分布中对添加到序列（如果per_channel为True，则为通道）的噪声进行采样。

**scale** (float, list, or tuple, optional) – Default: 0.1

随机噪声的标准偏差。

如果浮动，则所有噪声值都以相同的标准偏差进行采样。

如果是列表，则添加到序列（如果per_channel为True，则为通道）的噪声是从具有标准偏差的分布中采样的，该标准偏差是从列表中随机选择的。

如果是2元组，则从具有标准偏差的分布中对添加到序列（如果per_channel为True，则为通道）的噪声进行采样，该标准偏差是从区间中随机选择的。

**distr** (*str**,* *optional*) –  Default: ‘gaussian’  —optional：‘gaussian’, ‘laplace’，‘uniform’

随机噪声的分布。它必须是“高斯”、“拉普拉斯”和“均匀”中的一个

**kind** (*str**,* *optional*) –Default: ‘additive’ —optional：‘additive’ or ‘multiplicative’.

如何将噪波添加到原始时间序列中。它必须是“加法”或“乘法”。

**per_channel** (*bool**,* *optional*) –Default: True.

是为时间序列中的每个通道采样独立的噪声值，还是对时间序列中所有通道使用相同的噪声。

**normalize** (*bool**,* *optional*) –Default: True.

是否将噪声添加到归一化的时间序列中。如果为True，则首先将时间序列的每个通道标准化为[0，1]。

**repeats** (*int**,* *optional*) –Default: 1.

级数被扩充的次数。如果大于1，则一个级数将被独立地扩充多次。操作员也可以设置此参数。

**prob** (*float**,* *optional*) –Default: 1.0.

级数的概率是增广的。它必须在（0.0，1.0]中。此参数也可以由操作员设置

**seed** (*int**,* *optional*)  –Default: None.

随机数种子。

```python
X1 = tsaug.AddNoise(scale=0.1,).augment(npm_gr)
plot(X1)
```

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510155148288.png" alt="image-20230510155148288" style="zoom:80%;" />

当scale=0.01时：

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510154922854.png" alt="image-20230510154922854" style="zoom:80%;" />

原图：

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510155044015.png" alt="image-20230510155044015" style="zoom:80%;" />

### 2、tsaug.Convolve

使用内核窗口对时间序列进行卷积。

```python
classtsaug.Convolve(window='hann', size=7, per_channel=False, repeats=1, prob=1.0, seed=None)
```

**Parameters**

**window** (*str**,* *tuple**, or* *list**,* *optional*) –Default: “hann”.

如果是str或tuple，它是一个可以传递给scipy.signal.get_window的窗口类型。请参阅https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.get_window.html了解更多详细窗口选择类型。（有25个类型左右）

如果列表，它就是这样一个对象的列表。与时间序列卷积的内核窗口的类型是从该列表中随机采样的。

**size** (*int**,* *list**,* *tuple**,* *optional*) –Default: 7.

内核窗口的长度。
如果为int，则所有序列都与相同长度的窗口进行卷积。
如果是列表，则每个序列都与一个窗口进行卷积，该窗口的大小是从列表中随机采样的。
如果是2元组，则每个序列都与一个窗口进行卷积，该窗口的大小是从区间随机采样的。

**per_channel** (*bool**,* *optional*) – Default: False.

是为时间序列中的每个通道采样内核窗口，还是为时间序列的所有通道使用相同的窗口。仅在内核窗口不具有确定性时使用。

**repeats** (*int**,* *optional*) –Default: 1.

级数被扩充的次数。如果大于1，则一个级数将被独立地扩充多次。操作员也可以设置此参数

**prob** (*float**,* *optional*) –Default: 1.0.

级数的概率是增广的。它必须在（0.0，1.0]中。此参数也可以由操作员设置

**seed** (*int**,* *optional*) –Default: None.

```python
X2 = tsaug.Convolve(window="hann", size=7).augment(npm_gr)
plot(X2)
```

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510165540344.png" alt="image-20230510165540344" style="zoom:80%;" />

size=20

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510165641880.png" alt="image-20230510165641880" style="zoom:80%;" />

### 3、tsaug.Crop

从时间序列中裁剪随机子序列。
为了保证所有输出序列具有相同的长度，如果裁剪大小不确定，则必须将所有裁剪调整为固定长度。

```python
classtsaug.Crop(size, resize=None, repeats=1, prob=1.0, seed=None)
```

**Parameters**

**size** (*int**,* *tuple**,* *list*) –

随机剪切的长度。

如果为int，则所有裁剪的长度都相同。

如果是列表，则序列中的裁剪具有从该列表中随机采样的长度。

如果是2元组，则序列中的裁剪具有从该区间随机采样的长度。

**resize** (*int**,* *optional*) –

调整所有裁剪大小的长度。只有在裁剪大小不固定时才需要。

**repeats** (*int**,* *optional*) –Default: 1.

**prob** (*float**,* *optional*) –Default: 1.0.

**seed** (*int**,* *optional*) –  Default: None.

```python
X3 = tsaug.Crop(size=2).augment(npm_gr)
plot(X3)
```

size=2

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510161947458.png" alt="image-20230510161947458" style="zoom:80%;" />

size=7

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510162817968.png" alt="image-20230510162817968" style="zoom:80%;" />

size=95——注意size裁剪数不能大于数据总数

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510163411221.png" alt="image-20230510163411221" style="zoom:80%;" />

### 4、tsaug.Drift

漂移时间序列的值。
增广器使时间序列的值从其原始值随机平滑地漂移。漂移的程度由最大漂移和漂移点的数量控制。

```python
classtsaug.Drift(max_drift=0.5, n_drift_points=3, kind='additive', per_channel=True, normalize=True, repeats=1, prob=1.0, seed=None)
```

**Parameters**

**max_drift** (*float* *or* *tuple**,* *optional*) –Default: 0.5.

添加到时间序列中的最大漂移量。
如果float，则所有系列（如果per_channel为True，则所有通道）都以相同的最大值漂移。
如果tuple，则从该区间随机采样添加到时间序列（如果per_channel为True，则为通道）的最大漂移。

**n_drift_points** (*int* *or* *list**,* *optional*) –

一个新的漂移趋势的时间点的数量被定义为一系列。
如果为int，则所有系列（如果per_channel为True，则所有通道）都具有相同数量的漂移点。
如果为list，从该列表中随机采样一个系列中定义的漂移点数量（如果per_channel为True，则为一个通道）。

**kind** (*str**,* *optional*) – Default: ‘additive’.—*optional*：‘additive’ or ‘multiplicative’.

如何将噪波添加到原始时间序列中。它必须是“加法”或“乘法”。

**per_channel** (*bool**,* *optional*) –Default: True.

是为时间序列中的每个通道采样独立的漂移趋势，还是对时间序列中所有通道使用相同的漂移趋势。

**normalize** (*bool**,* *optional*) –Default: True.

**repeats** (*int**,* *optional*) –Default: 1.

**prob** (*float**,* *optional*) –Default: 1.0.

**seed** (*int**,* *optional*) –Default: None.

```python
X4 = tsaug.Drift(max_drift=0.1, n_drift_points=1).augment(npm_gr)
plot(X4)
```

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510171705487.png" alt="image-20230510171705487" style="zoom:80%;" />

当max_drift=1（主）, n_drift_points=1（n_drift_points=10、100、1000无变化）

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510171824609.png" alt="image-20230510171824609" style="zoom:80%;" />

###  5、tsaug.Dropout

时间序列中某些随机时间点的丢弃值。
单个时间点或子序列可能会被删除。

```python
classtsaug.Dropout(p=0.05, size=1, fill='ffill', per_channel=False, repeats=1, prob=1.0, seed=None)
```

**Parameters**

**p** (*float**,* *tuple**, or* *list**,* *optional*) –Default: 0.05.

一个时间点的值被丢弃的概率。
如果float，则所有系列（如果per_channel为True，则所有通道）都具有相同的概率。
如果是列表，则序列（如果per_channel为True，则为通道）具有从该列表中随机采样的概率。
如果是2元组，则序列（如果per_channel为True，则为通道）具有从该区间随机采样的概率。

**size** (*int**,* *tuple**, or* *list**,* *optional*) –Default: 1.

丢弃单元的大小。
如果为int，则所有删除的单元都具有相同的大小。
如果是列表，则从该列表中随机抽取一个退出单元的大小。
如果是2元组，则丢弃的单元具有从该区间随机采样的大小。
请注意，丢弃的单元可能会重叠，从而有效地产生更大的单元，尽管如果p很小，则概率很低。

**fill** (*str* *or* *float**,* *optional*) –Default: ‘ffill’.

如何填充丢掉的值。
如果为“ffill”，请填充上一个未删除的值。
如果为“bfill”，则使用未删除的第一个下一个值进行填充。
如果为“mean”，则填写该系列中该通道的平均值。
如果是浮点型，请填充此值。

**per_channel** (*bool**,* *optional*) –Default: False.

是对时间序列中的每个通道独立地采样丢弃单元，还是对时间序列的所有通道使用相同的丢弃单元。

**repeats** (*int**,* *optional*) –Default: 1.

**prob** (*float**,* *optional*) –Default: 1.0.

**seed** (*int**,* *optional*) – Default: None.

```python
X5 = tsaug.Dropout(p=0.1, size=1, fill=float("nan"),seed=5).augment(npm_gr)
plot(X5)
```

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510175912370.png" alt="image-20230510175912370" style="zoom:80%;" />

fill=‘mean’（删除的地方均值填充）

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510180221336.png" alt="image-20230510180221336" style="zoom:80%;" />

### 6、tsaug.Pool

在不改变长度的情况下降低时间分辨率。

```python
classtsaug.Pool(kind='ave', size=2, per_channel=False, repeats=1, prob=1.0, seed=None)
```

**Parameters**

**kind** (*str**,* *optional*) –Default: ‘ave’.—*optional*： ‘max’, ‘min’, ‘ave’

池化功能“max”、“min”和“ave”之一

**size** (*str**,* *tuple**, or* *list**,* *optional*) –Default: 2.

池化窗口的大小。
如果为int，则所有系列（如果per_channel为True，则所有通道）都使用相同的池大小进行池化。
如果是列表，则一个系列（如果per_channel为True，则为一个通道）将以从该列表中随机采样的池大小进行池化。
如果是2元组，则一个序列（如果per_channel为True，则为一个通道）被池化，池化大小从该区间随机采样。

**per_channel** (*bool**,* *optional*) – Default: False.

是为时间序列中的每个通道采样池窗口，还是对时间序列中所有通道使用相同的窗口。仅在池化窗口不具有确定性时使用。

**repeats** (*int**,* *optional*) –Default: 1.

**prob** (*float**,* *optional*) –Default: 1.0.

**seed** (*int**,* *optional*) – Default: None.

```python
X6 = tsaug.Pool(kind='ave', size=2, per_channel=False, repeats=1, prob=1.0, seed=None).augment(npm_gr)
plot(X6)
```

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510201533930.png" alt="image-20230510201533930" style="zoom:80%;" />

size=10

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510201459799.png" alt="image-20230510201459799" style="zoom:80%;" />

### 7、tsaug.Quantize

将时间序列量化到一个水平集。
时间序列中的值四舍五入到级别集中最近的级别。

```python
classtsaug.Quantize(n_levels=10, how='uniform', per_channel=False, repeats=1, prob=1.0, seed=None)
```

**Parameters**

**n_levels** (*int**,* *tuple**, or* *list**,* *optional*) –Default: 10.

如果是一个整数，表示所有序列（如果per_channel为True，则是所有通道）将被量化为该大小的级别集。
如果是一个列表，表示序列（如果per_channel为True，则是通道）将被量化为从该列表中随机抽样的级别集。
如果是一个2元组，表示序列（如果per_channel为True，则是通道）将被量化为从该间隔中随机抽样的级别集。

**how** (*str**,* *optional*) –Default: ‘uniform’.—*optional*：'uniform'、'quantile'、'kmeans'

定义级别集的方法。
如果“uniform”，则通过均匀离散该系列中该通道的范围来定义级别集。
如果是“quantile”，则级别集由该系列中该通道中的值的分位数定义。
如果是“kmeans”，则通过该系列中该通道中的值的k-means聚类来定义级别集。请注意，这种方法可能很慢。

**per_channel** (*bool**,* *optional*) –Default: False.

**repeats** (*int**,* *optional*) –Default: 1.

**prob** (*float**,* *optional*) –Default: 1.0.

**seed** (*int**,* *optional*) –  Default: None.

```python
X7 = tsaug.Quantize(n_levels=1,how='uniform').augment(npm_gr)
plot(X7)
```

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510203544980.png" alt="image-20230510203544980" style="zoom:80%;" />

n_levels=10

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510203620674.png" alt="image-20230510203620674" style="zoom:80%;" />

n_levels=20

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510203738743.png" alt="image-20230510203738743" style="zoom:80%;" />

### 8、tsaug.Resize

更改时间序列的时间分辨率。
调整大小的时间序列是通过对原始时间序列进行线性插值来获得的。

```python
classtsaug.Resize(size, repeats=1, prob=1.0, seed=None)
```

**Parameters**

**size** (*int*) – 

输出序列的长度。

**repeats** (*int**,* *optional*) –Default: 1.

**prob** (*float**,* *optional*) – Default: 1.0.

**seed** (*int**,* *optional*) – Default: None.

```python
X8 = tsaug.Resize(size=20).augment(npm_gr)
plot(X8)
```

相当于吧总体曲线趋势压缩为20个值，size为设置输出值的数量

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510212649601.png" alt="image-20230510212649601" style="zoom:80%;" />

size=50

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510212833898.png" alt="image-20230510212833898" style="zoom:80%;" />

### 9、tsaug.Reverse

反转序列的时间线。

```python
classtsaug.Reverse(repeats=1, prob=1.0, seed=None)
```

**Parameters**

**repeats** (*int**,* *optional*) –Default: 1.

**prob** (*float**,* *optional*) –Default: 1.0.

级数被扩充的次数。如果大于1，则一个级数将被独立地扩充多次。这个参数也可以由算子设置。级数的概率是增广的。它必须在（0.0，1.0]中。此参数也可以由操作员设置

**seed** (*int**,* *optional*) – Default: None.

```python
X9 = tsaug.Reverse().augment(npm_gr)
plot(X9)
```

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510213901390.png" alt="image-20230510213901390" style="zoom:80%;" />

### 10、tsaug.TimeWarp

随机时间扭曲。
增强随机改变了时间线的速度。时间扭曲由速度变化的次数和最大/最小速度的最大比率控制。

```
classtsaug.TimeWarp(n_speed_change=3, max_speed_ratio=3.0, repeats=1, prob=1.0, seed=None)
```

**Parameters**

**n_speed_change** (*int**,* *optional*) –Default: 3.

每个序列中的速度变化次数。

**max_speed_ratio** (*float**,* *tuple**, or* *list**,* *optional*) –Default: 3.0.

翘曲时间线中最大/最小速度的最大比值。如果该值较大，则序列的时间线更有可能被显著扭曲。
如果是float，则所有系列都以相同的比例进行扭曲。
如果是list，则每个系列都会以从列表中随机采样的比例进行扭曲。
如果是2元组，则每个序列都以从区间随机采样的比率进行扭曲。

**repeats** (*int**,* *optional*) – Default: 1.

**prob** (*float**,* *optional*) –Default: 1.0.

**seed** (*int**,* *optional*) –  Default: None.

```python
X10 = tsaug.TimeWarp(n_speed_change=3,max_speed_ratio=3).augment(npm_gr)
plot(X10)
```

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510215159641.png" alt="image-20230510215159641" style="zoom:80%;" /><img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510215235976.png" alt="image-20230510215235976" style="zoom:80%;" />

TimeWarp如果不设置随机数种子每次结果会不一样！

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510215327371.png" alt="image-20230510215327371" style="zoom:80%;" /><img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510215703127.png" alt="image-20230510215703127" style="zoom:80%;" />

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510215720816.png" alt="image-20230510215720816" style="zoom:80%;" />

n_speed_change=5,max_speed_ratio=5（当数据量非常大时可以吧n_speed_change数量设置大，表示每条线需要有多少随机的段需要变化。而max_speed_ratio影响交小可以用默认）

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510215826539.png" alt="image-20230510215826539" style="zoom:80%;" /><img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510215849469.png" alt="image-20230510215849469" style="zoom:80%;" />

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510215914764.png" alt="image-20230510215914764" style="zoom:80%;" />

## 管道使用

建立一个增强型管道，如下所示：

```python
my_pipeline=(
            tsaug.TimeWarp(n_speed_change=3,max_speed_ratio=3)*3 # 随机时间扭曲3次,出3张图
            +tsaug.Quantize(n_levels=[10, 20, 30],how='uniform')  #随机量化到10、20或30级集合
            +tsaug.Drift(max_drift=(0.1,0.5)) @ 0.8  #以80%的概率将信号随机漂移高达10%-50%
) 
X11 = my_pipeline.augment(npm_gr)
plot(X11)
```

<img src="tsaug%E5%BA%93%E7%9B%B8%E5%85%B3%E4%BB%8B%E7%BB%8D%E5%8F%8A%E5%86%85%E5%AE%B9.assets/image-20230510224318194.png" alt="image-20230510224318194" style="zoom:80%;" />



